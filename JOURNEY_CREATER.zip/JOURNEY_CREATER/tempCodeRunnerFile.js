else if (hex2[0] === " ") {
            //   continue;
            // }